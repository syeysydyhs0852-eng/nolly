require('dotenv').config();
const express = require('express');
const path = require('path');
const config = require('./config');
const middleware = require('./middleware');
const routes = require('./routes');
const webhooks = require('./webhooks');
const health = require('./health');

const app = express();
app.use(middleware.securityHeaders);
app.use(middleware.cors);
app.use('/api/webhooks', express.raw({ type: 'application/json' }), webhooks.router);
app.use(express.json({ limit: '1mb' }));
app.use(middleware.requestLogger);
app.use('/api', middleware.apiLimiter);
app.use('/api', routes);
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/health', health.handler);
app.get('*', (req,res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.use(middleware.notFound);
app.use(middleware.errorHandler);

if (require.main === module) {
  app.listen(config.port, () => console.log(`NollyHost API listening on http://localhost:${config.port}`));
}
module.exports = app;
