document.addEventListener('DOMContentLoaded',()=>{
 const year=document.querySelectorAll('[data-year]');year.forEach(x=>x.textContent=new Date().getFullYear());
 document.querySelectorAll('[data-menu]').forEach(btn=>btn.addEventListener('click',()=>document.querySelector('[data-nav]')?.classList.toggle('open')));
 document.querySelectorAll('[data-share]').forEach(btn=>btn.addEventListener('click',async()=>{
  const url=location.href; if(navigator.share){try{await navigator.share({title:'NollyHost',url});}catch{}}
  else {await navigator.clipboard?.writeText(url);btn.textContent='Copied!';}
 }));
});
