// Simple navigation enhancement. Traditional HTML routes remain valid and refreshable.
document.addEventListener('click',e=>{const a=e.target.closest('a[data-route]');if(!a||e.ctrlKey||e.metaKey)return;e.preventDefault();location.href=a.href;});
