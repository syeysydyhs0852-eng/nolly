const fs = require('fs');
const path = require('path');
const required = ['server.js','config.js','database.js','public/index.html','.env.example','.gitignore'];
let failed = 0;
for (const file of required) {
  const ok = fs.existsSync(path.join(__dirname,file));
  console.log(`${ok ? '[PASS]' : '[FAIL]'} ${file}`);
  if (!ok) failed++;
}
const envIgnore = fs.readFileSync(path.join(__dirname,'.gitignore'),'utf8').includes('.env');
console.log(`${envIgnore ? '[PASS]' : '[FAIL]'} .env ignored`);
if (!envIgnore) failed++;
console.log(`\n${failed ? `${failed} check(s) failed` : 'Basic scaffold checks passed'}`);
process.exit(failed ? 1 : 0);
