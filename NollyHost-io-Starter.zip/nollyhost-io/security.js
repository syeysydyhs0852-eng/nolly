const crypto = require('crypto');
function verifyPaystackSignature(rawBody, signature, secret) {
  if (!secret || !signature) return false;
  const digest = crypto.createHmac('sha512', secret).update(rawBody).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(signature)); } catch { return false; }
}
function verifyStripeSignature(stripe, rawBody, signature, secret) {
  if (!stripe || !secret || !signature) return null;
  try { return stripe.webhooks.constructEvent(rawBody, signature, secret); } catch { return null; }
}
module.exports = { verifyPaystackSignature, verifyStripeSignature };
