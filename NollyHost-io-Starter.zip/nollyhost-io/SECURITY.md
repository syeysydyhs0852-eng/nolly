# Security notes and launch hardening

- Secrets belong only in backend environment variables, never in HTML or browser JavaScript.
- `.env` is ignored by Git. `.env.example` contains placeholders only.
- Configure HTTPS, exact CORS origins, provider webhook secrets, OAuth redirect URLs, database policies, and backups.
- This scaffold includes basic security headers, request validation, rate limiting, and webhook signature verification. These are not a substitute for a security review.
- Admin access is not production-ready until real identity authentication, MFA, role permissions, and secure session handling are configured.
- Do not enable provisioning before payment verification, idempotency, provider testing, and refund/support procedures are in place.
- Location and device data collection must be minimized and disclosed in a privacy policy.
