const registrar=require('../services/resellerclub.service');
exports.search=async(req,res)=>{const domain=String(req.query.domain||'').trim().toLowerCase();if(!domain||domain.length>253)return res.status(400).json({error:'Enter a valid domain'});try{const result=await registrar.search(domain);res.json(result);}catch(e){res.status(503).json({error:e.message});}};
exports.pricing=(req,res)=>res.json({configured:false,items:[],message:'Set real domain prices in the admin database/provider configuration.'});
