const paystack=require('../services/paystack.service');
const stripe=require('../services/stripe.service');
exports.paystackInitialize=async(req,res)=>{try{const result=await paystack.initialize(req.body);res.json(result);}catch(e){res.status(400).json({error:e.message});}};
exports.stripeCheckout=async(req,res)=>{try{const result=await stripe.createCheckout(req.body);res.json(result);}catch(e){res.status(400).json({error:e.message});}};
