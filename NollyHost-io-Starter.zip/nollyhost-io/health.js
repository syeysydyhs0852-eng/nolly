const database = require('./database');
async function handler(req,res) {
  const db = await database.status();
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString(), services: { database: db, paystack: !!process.env.PAYSTACK_SECRET_KEY, stripe: !!process.env.STRIPE_SECRET_KEY } });
}
module.exports = { handler };
