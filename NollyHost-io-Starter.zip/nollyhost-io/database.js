const { createClient } = require('@supabase/supabase-js');
const config = require('./config');
let client;
function getSupabase() {
  if (!config.supabaseUrl || !config.supabaseServiceKey) return null;
  if (!client) client = createClient(config.supabaseUrl, config.supabaseServiceKey, { auth: { persistSession: false } });
  return client;
}
async function status() {
  const db = getSupabase();
  if (!db) return { configured: false, connected: false };
  const { error } = await db.from('health_check').select('*').limit(1);
  return { configured: true, connected: !error, error: error?.message || null };
}
module.exports = { getSupabase, status };
