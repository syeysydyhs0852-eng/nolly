# NollyHost.io — Starter Production Scaffold

NollyHost is a domain, hosting, website-builder, billing and customer-management platform scaffold.

**Important:** This ZIP is a runnable foundation, not a fully operational hosting company. Real domain registration, hosting provisioning, email, SMS, payments, OAuth, AI, and deployment require provider accounts, credentials, configuration, testing, and production hardening.

## Quick start
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Add Supabase and provider credentials as needed.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

Health: `http://localhost:3000/api/health`

## Frontend
Static HTML pages have their CSS embedded. Shared browser code is in `public/js/`. This starter uses a page-navigation approach rather than pretending all 40+ routes are already implemented. The primary pages are Home, Domains, Hosting, Builder, Checkout, Dashboard, Admin, and Login.

## Live integrations
- Supabase: database/auth/storage/realtime configuration is prepared.
- Paystack: checkout initialization and webhook signature verification are implemented.
- Stripe: checkout session initialization and webhook signature verification are implemented.
- Domain registrar and WHM/cPanel: adapter boundaries are prepared; they require provider-specific API access and product setup.
- Email/SMS/AI: service placeholders fail clearly when unconfigured.

Never commit `.env`. Do not use production credentials in local development. Before launch, review `SECURITY.md`, test payment webhooks, and complete the launch checklist.
