const express = require('express');
const config = require('./config');
const security = require('./security');
const paystack = require('./services/paystack.service');
const stripeService = require('./services/stripe.service');
const router = express.Router();

router.post('/paystack', (req,res) => {
  const signature = req.headers['x-paystack-signature'];
  if (!security.verifyPaystackSignature(req.body, signature, config.paystackWebhookSecret)) return res.status(401).send('Invalid signature');
  let event;
  try { event = JSON.parse(req.body.toString('utf8')); } catch { return res.status(400).send('Invalid payload'); }
  paystack.handleWebhook(event).catch(err => console.error('Paystack webhook handling failed:', err.message));
  res.status(200).json({ received: true });
});
router.post('/stripe', (req,res) => {
  const event = stripeService.verifyWebhook(req.body, req.headers['stripe-signature']);
  if (!event) return res.status(400).send('Invalid signature');
  stripeService.handleWebhook(event).catch(err => console.error('Stripe webhook handling failed:', err.message));
  res.status(200).json({ received: true });
});
module.exports = { router };
