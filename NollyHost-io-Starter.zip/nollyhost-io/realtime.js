const db = require('./database');
function subscribe(table, callback) {
  const client = db.getSupabase();
  if (!client) throw new Error('Realtime is not configured');
  return client.channel(`nollyhost-${table}`).on('postgres_changes', { event: '*', schema: 'public', table }, callback).subscribe();
}
module.exports = { subscribe };
