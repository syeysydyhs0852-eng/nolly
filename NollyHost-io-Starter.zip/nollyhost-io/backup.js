async function backupStatus() {
  return { configured: false, message: 'Configure Supabase automated backups and a tested external backup destination.' };
}
module.exports = { backupStatus };
