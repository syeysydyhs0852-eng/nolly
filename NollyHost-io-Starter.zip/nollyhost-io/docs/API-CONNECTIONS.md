# API connections

## Supabase
Create a Supabase project. Add its URL, anon key, and service-role key to backend environment variables. Keep the service-role key server-side only. Create tables and policies before enabling user data features.

## Paystack
Create a Paystack account, configure test keys first, and set the webhook URL to `https://YOUR_DOMAIN/api/webhooks/paystack`. Use the secret key on the backend. Test signature verification and payment amount/reference matching.

## Stripe
Create a Stripe account, use test keys, and configure webhook events for checkout completion/payment status. Webhook endpoint: `https://YOUR_DOMAIN/api/webhooks/stripe`. Configure the endpoint signing secret.

## Google OAuth
Create OAuth credentials in Google Cloud Console. Set allowed origins and redirect URLs to your actual site. Authentication implementation is a starting point; finish secure callback/session flow before launch.

## Domain registrar
Choose a registrar/reseller that supports your desired TLDs, API access, registration, renewals, transfers, DNS, and account balance. Request credentials and implement the adapter in `services/resellerclub.service.js` or your chosen provider adapter. Test in a sandbox if available.

## WHM/cPanel
Provision a WHM server/provider, create an API token with least privileges, restrict token access by IP, and configure server URL/token. The included service is a safe adapter boundary, not an active provisioning integration.

## Email/SMS/AI
Configure a verified email sender and SMS account. Obtain credentials and set DNS SPF/DKIM/DMARC. AI calls must have quotas, abuse controls, and billing limits.
