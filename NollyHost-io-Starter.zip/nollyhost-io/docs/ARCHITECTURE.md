# Architecture

Browser HTML pages (embedded CSS) → shared JavaScript/API client → Express API → routes/controllers/services → Supabase and external providers.

Long-running or retryable work should be queued rather than performed inside checkout HTTP requests. Production needs durable queues, idempotency, monitoring, backups, and provider-specific provisioning workflows.
