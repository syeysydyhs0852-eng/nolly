const config=require('../config');
let stripe;
function client(){if(!config.stripeSecret)throw new Error('Stripe secret key is not configured');if(!stripe)stripe=require('stripe')(config.stripeSecret);return stripe;}
async function createCheckout({items,email,success_url,cancel_url}={}) {
  if(!Array.isArray(items)||!items.length)throw new Error('Cart is empty');
  // Do not accept arbitrary client prices in production. Replace with DB product lookup.
  if(items.some(x=>!x.priceId))throw new Error('Stripe Price IDs must be supplied from trusted server-side product records');
  const session=await client().checkout.sessions.create({mode:'payment',customer_email:email,line_items:items.map(x=>({price:x.priceId,quantity:Math.max(1,Number(x.quantity||1))})),success_url,cancel_url});
  return {url:session.url,id:session.id};
}
function verifyWebhook(raw,signature){try{return client().webhooks.constructEvent(raw,signature,config.stripeWebhookSecret);}catch{return null;}}
async function handleWebhook(event){if(event.type==='checkout.session.completed')console.log('Stripe checkout completed event received; verify order and enqueue fulfillment before activation.');}
module.exports={createCheckout,verifyWebhook,handleWebhook};
