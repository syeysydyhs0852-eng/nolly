const config=require('../config');
async function initialize({email,amount,currency='NGN',reference,callback_url,metadata}={}) {
  if(!config.paystackSecret) throw new Error('Paystack secret key is not configured');
  if(!email||!amount||!reference) throw new Error('Email, amount, and reference are required');
  const response=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${config.paystackSecret}`,'Content-Type':'application/json'},body:JSON.stringify({email,amount:Math.round(Number(amount)*100),currency,reference,callback_url,metadata})});
  const data=await response.json();
  if(!response.ok||!data.status) throw new Error(data.message||'Paystack initialization failed');
  return data.data;
}
async function handleWebhook(event) {
  if(event.event==='charge.success') {
    // TODO: atomically verify reference/amount/currency against an order, enforce idempotency, then enqueue fulfillment.
    console.log('Paystack charge.success received; fulfillment is not enabled until order verification is implemented.');
  }
}
module.exports={initialize,handleWebhook};
