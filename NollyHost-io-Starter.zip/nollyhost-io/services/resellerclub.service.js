async function search(domain) {
  if (!process.env.RESELLERCLUB_API_KEY) throw new Error('Domain registrar API is not configured');
  // Provider-specific endpoint, authentication and TLD product mapping must be completed.
  throw new Error('Registrar adapter is not implemented yet; no availability is fabricated');
}
module.exports={search};
