const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const config = require('./config');
function securityHeaders(req,res,next) {
  helmet({ contentSecurityPolicy: false })(req,res,next);
}
function corsMiddleware(req,res,next) {
  cors({ origin: config.corsOrigin, credentials: true })(req,res,next);
}
const apiLimiter = rateLimit({ windowMs: 60*1000, limit: 100, standardHeaders: true, legacyHeaders: false });
function requestLogger(req,res,next) { const start=Date.now(); res.on('finish',()=>console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now()-start}ms`)); next(); }
function notFound(req,res) { res.status(404).json({ error: 'Not found' }); }
function errorHandler(err,req,res,next) { console.error(err); res.status(err.status || 500).json({ error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message }); }
module.exports = { securityHeaders, cors: corsMiddleware, apiLimiter, requestLogger, notFound, errorHandler };
