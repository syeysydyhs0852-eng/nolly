const crypto = require('crypto');
function safeEqual(a, b) {
  const left = Buffer.from(String(a || ''));
  const right = Buffer.from(String(b || ''));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}
function money(amount, currency='NGN') {
  return new Intl.NumberFormat('en', { style: 'currency', currency }).format(Number(amount || 0));
}
function cleanText(value, max=500) {
  return String(value ?? '').replace(/[<>]/g, '').trim().slice(0, max);
}
module.exports = { safeEqual, money, cleanText };
