#!/usr/bin/env bash
set -e
if ! command -v vercel >/dev/null; then
  echo "Vercel CLI not found. Install with: npm i -g vercel"
  exit 1
fi
npm test
vercel --prod
