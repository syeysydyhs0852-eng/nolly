#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
if ! command -v node >/dev/null; then echo "Node.js 20+ is required"; exit 1; fi
if [ ! -f .env ]; then cp .env.example .env; echo "Created .env. Add credentials before enabling live integrations."; fi
npm install
npm run dev
